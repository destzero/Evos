from aiogram import Dispatcher, Bot, filters, types, F
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
import asyncio

bot = Bot(token="6927667204:AAGJQxxaEIBaaDCdJM_6r9mvTxyBZMpKb88")
dp = Dispatcher(bot=bot)

kb = [
    [KeyboardButton(text="/Hot_dog")],
    [KeyboardButton(text="/Gamburger")],
    [KeyboardButton(text="/Grill")]
]
mb = ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

kb_1 = [
    [KeyboardButton(text="/Menu")]
]
mb_1 = ReplyKeyboardMarkup(keyboard=kb_1, resize_keyboard=True)

@dp.message(filters.Command("start"))
async def start_function(message: types.Message):
    await message.answer(f"Salom {message.from_user.full_name}, botga xush kelibsiz !!!", reply_markup=mb_1)

@dp.message(filters.Command("Menu"))
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://img.pikbest.com/origin/06/29/43/57ApIkbEsTsEk.jpg!w700wp",
        caption="Salom menu bilan tanishing. \n 1 /Hot_dog \n 2 /Gamburger \n 3 /Grill", reply_markup=mb)


@dp.message(filters.Command("Hot_dog"))
async def echo_function(message: types.Message):
    await message.answer_photo(photo="https://popmenucloud.com/cdn-cgi/image/width%3D600%2Cheight%3D600%2Cfit%3Dscale-down%2Cformat%3Dauto%2Cquality%3D60/cmywfkhq/029d700e-6b13-4de0-b782-6a4e5b8d9f56.jpg",
                               caption="Hot Dog 10 000 so'm")

@dp.message(filters.Command("Gamburger"))
async def echo_function(message: types.Message):
    await message.answer_photo(photo="https://img.delo-vcusa.ru/2015/07/86.jpg",
                               caption="Gamburger 16 000 so'm")

@dp.message(filters.Command("Grill"))
async def echo_function(message: types.Message):
    await message.answer_photo(photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9_-d2jyNiuKeBSAsLujahkJqmAYp1N9vb1w&s",
                               caption="Grill 32 000 so'm")


async def main():
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.run(main())