from aiogram import Dispatcher, Bot, filters, types, F
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
import asyncio

bot = Bot(token="7444244618:AAHJxtEgNBg4dgQC5Yhvd5Vs9t51PzF1sh0")
dp = Dispatcher(bot=bot)

kb = [
    [KeyboardButton(text="Hot_dog(3)"), KeyboardButton(text="Gamburger(3)"), KeyboardButton(text="Fries(3)")]
]
mb = ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

menutop = [
    [KeyboardButton(text="Ovqatlar"), KeyboardButton(text="Ichimlikar")]
]
mmenutop = ReplyKeyboardMarkup(keyboard=menutop, resize_keyboard=True)

menuwater = [
    [KeyboardButton(text="Pepsi(1.5l)"), KeyboardButton(text="Suv(1.5l)"), KeyboardButton(text="Sharbat(1.5l)")]
]
mmenuwater = ReplyKeyboardMarkup(keyboard=menuwater, resize_keyboard=True)

kb_1 = [
    [KeyboardButton(text="Menu")]
]
mb_1 = ReplyKeyboardMarkup(keyboard=kb_1, resize_keyboard=True)

kb_2 = [
    [KeyboardButton(text="Fries_medium"), KeyboardButton(text="Fries_short"), KeyboardButton(text="Fries_long")]
]
mb_2 = ReplyKeyboardMarkup(keyboard=kb_2, resize_keyboard=True)

kb_3 = [
    [KeyboardButton(text="Chesse_burger"), KeyboardButton(text="Simple_burger"), KeyboardButton(text="Chili_burger")]
]
mb_3 = ReplyKeyboardMarkup(keyboard=kb_3, resize_keyboard=True)

kb_4 = [
    [KeyboardButton(text="Hot_dog_medium"), KeyboardButton(text="Hot_dog_short"), KeyboardButton(text="Hot_dog_long")]
]
mb_4 = ReplyKeyboardMarkup(keyboard=kb_4, resize_keyboard=True)

@dp.message(filters.Command("start"))
async def start_function(message: types.Message):
    await message.answer(f"Salom {message.from_user.full_name}, botga xush kelibsiz !!!", reply_markup=mb_1)

@dp.message(F.text == "Menu")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://static.vecteezy.com/system/resources/previews/016/063/037/original/fast-food-restaurant-table-menu-template-vector.jpg",
        caption="Menu bilan tanishing", reply_markup=mmenutop)

@dp.message(F.text == "Ovqatlar")
async def ovqat_function(message: types.Message):
    await message.answer(caption="Ovqat turini tanlang", reply_markup=mb)

@dp.message(F.text == "Ichimliklar")
async def ovqat_function(message: types.Message):
    await message.answer(caption="Ichimlik turini tanlang", reply_markup=menuwater)

@dp.message(F.text == "Pepsi(1.5l)")
async def pepsi_function(message: types.Message):
    await message.answer_photo(photo="https://orzon.uz/upload/iblock/359/3597fe28c257438dcb94643a7f71af0d.jpg",
    caption="Narxi:15ming so'm")

@dp.message(F.text == "Suv(1.5l)")
async def pepsi_function(message: types.Message):
    await message.answer_photo(photo="https://www.icemountainwater.com/sites/g/files/zmtnxh171/files/2022-10/ice_mountain-spring-water-product-detail--1.5L-single-right.png",
    caption="Narxi:7ming so'm")

@dp.message(F.text == "Sharbat(1.5l)")
async def pepsi_function(message: types.Message):
    await message.answer_photo(photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1TOQZ67PqIP-4qaUvaydlTauPXb9h3hYrJg&s",
    caption="Narxi:10ming so'm")

@dp.message(F.text == "Fries(3)")
async def start_function(message: types.Message):
    await message.answer(text="Frieni tanlang ", reply_markup=mb_2)

@dp.message(F.text == "Gamburger(3)")
async def start_function(message: types.Message):
    await message.answer(text="Burgerni tanlang ", reply_markup=mb_3)

@dp.message(F.text == "Hot_dog(3)")
async def start_function(message: types.Message):
    await message.answer(text="Hot dogni tanlang ", reply_markup=mb_4)

@dp.message(F.text == "Fries_medium")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://s7d1.scene7.com/is/image/mcdonalds/DC_202002_8932_MediumFries_832x472:1-3-product-tile-desktop?wid=765&hei=472&dpr=off",
    caption="Narxi:13ming so'm")

@dp.message(F.text == "Fries_long")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://i.ytimg.com/vi/tguPrkEJoFY/maxresdefault.jpg",
    caption="Narxi 15ming so'm")

@dp.message(F.text == "Fries_short")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBzqoyf7fvJORIQ_ZOuGodnhEIXjm5gE73bg&s",
    caption="Narxi 10ming so'm")

@dp.message(F.text == "Chesse_burger")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://s7d1.scene7.com/is/image/mcdonalds/mcdonalds-triple-cheeseburger-april-promo:nutrition-calculator-tile?wid=822&hei=822&dpr=off",
    caption="Narxi 22ming so'm")

@dp.message(F.text == "Chili_burger")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlvUPYubVQ1oEVPTEyEzBQlfUPHxisrT1PBw&s",
    caption="Narxi 23ming so'm")

@dp.message(F.text == "Simple_burger")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://assets.epicurious.com/photos/57c5c6d9cf9e9ad43de2d96e/master/pass/the-ultimate-hamburger.jpg",
    caption="Narxi 20ming so'm")

@dp.message(F.text == "Hot_dog_medium")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://www.licious.in/blog/wp-content/uploads/2016/07/Hot-Dogs.jpg",
    caption="Narxi 20ming so'm")

@dp.message(F.text == "Hot_dog_short")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://cdn.jwplayer.com/v2/media/25Ez4pc2/poster.jpg?width=720",
    caption="Narxi 20ming so'm")

@dp.message(F.text == "Hot_dog_long")
async def start_function(message: types.Message):
    await message.answer_photo(photo="https://sausageman.co.uk/wp-content/uploads/2015/11/foot-long-sausage.jpg",
    caption="Narxi 20ming so'm")

async def main():
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())